package com.RestApi.RestApi.service;

import java.util.List;

import com.RestApi.RestApi.controller.entities.Course;

public interface CourceServices {
	public List<Course> getCourses();
	public Course getCourse(long course);
	public Course addCourse(Course course);
}
